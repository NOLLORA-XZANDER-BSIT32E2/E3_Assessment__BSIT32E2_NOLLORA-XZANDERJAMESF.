﻿//----------TRIANGLE AREA CALCULATOR------------

// using System;

// class TriangleAreaCalculator
//  {
//      static void Main()
//     {
//         Console.WriteLine("Triangle Area Calculator");

//         Console.Write("Enter the base of the triangle: ");
//         double baseLength = Convert.ToDouble(Console.ReadLine());

//         Console.Write("Enter the height of the triangle: ");
//         double height = Convert.ToDouble(Console.ReadLine());


//         double area = CalculateTriangleArea(baseLength, height);


//         Console.WriteLine($"The area of the triangle with base {baseLength} and height {height} is: {area}");
//     }

//     static double CalculateTriangleArea(double baseLength, double height)
//     {
//         return 0.5 * baseLength * height;
//     }
// }


//----------ARRAY OPERATIONS------------

// using System;

// class Program
// {
//     static void Main()
//     {
//         int[] numbers = new int[5];

//         for (int i = 0; i < 5; i++)
//         {
//             numbers[i] = (i + 1) * (i + 1);
//         }

//         Console.WriteLine("Array elements:");
//         foreach (var num in numbers)
//         {
//             Console.Write(num + " ");
//         }
//         Console.WriteLine(); 

//         int largestElement = FindLargestElement(numbers);
//         Console.WriteLine($"The largest element in the array is: {largestElement}");
//     }

//     static int FindLargestElement(int[] array)
//     {
//         int max = array[0];

//         for (int i = 1; i < array.Length; i++)
//         {
//             if (array[i] > max)
//             {
//                 max = array[i];
//             }
//         }

//         return max;
//     }
// }

//----------SIMPLE FOR LOOP------------

// using System;

// class Program
// {
//     static void Main()
//     {
//         Console.WriteLine("Number   |  Square Root");
//         Console.WriteLine("------------------------");

//         for (int i = 1; i <= 10; i++)
//         {
//             double squareRoot = Math.Sqrt(i);
//             Console.WriteLine($"{i,-9} |  {squareRoot}");
//         }
//     }
// }
