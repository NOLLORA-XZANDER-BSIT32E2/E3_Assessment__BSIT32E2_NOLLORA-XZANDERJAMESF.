﻿//----------TRIANGLE AREA CALCULATOR------------

// using System;

// class TriangleAreaCalculator
//  {
//      static void Main()
//     {
//         Console.WriteLine("Triangle Area Calculator");

//         Console.Write("Enter the base of the triangle: ");
//         double baseLength = Convert.ToDouble(Console.ReadLine());

//         Console.Write("Enter the height of the triangle: ");
//         double height = Convert.ToDouble(Console.ReadLine());


//         double area = CalculateTriangleArea(baseLength, height);


//         Console.WriteLine($"The area of the triangle with base {baseLength} and height {height} is: {area}");
//     }

//     static double CalculateTriangleArea(double baseLength, double height)
//     {
//         return 0.5 * baseLength * height;
//     }
// }


//----------ARRAY OPERATIONS------------

// using System;

// class Program
// {
//     static void Main()
//     {
//         int[] numbers = new int[5];

//         Console.Write("Enter a formula for array elements (e.g., n * 2): ");
//         string? formula = Console.ReadLine();

        
//         if (formula != null)
//         {
            
//             for (int i = 0; i < numbers.Length; i++)
//             {
//                 numbers[i] = EvaluateFormula(formula, i + 1);
//             }

            
//             Console.WriteLine("Array elements:");
//             DisplayArrayElements(numbers);

            
//             int largestElement = FindLargestElement(numbers);
//             Console.WriteLine($"The largest element in the array is: {largestElement}");
//         }
//         else
//         {
//             Console.WriteLine("Invalid input. Exiting program.");
            
//         }
//     }

//     static void DisplayArrayElements(int[] array)
//     {
//         foreach (var num in array)
//         {
//             Console.Write(num + " ");
//         }
//         Console.WriteLine();
//     }

//     static int FindLargestElement(int[] array)
//     {
//         if (array.Length == 0)
//         {
//             throw new ArgumentException("Array is empty");
//         }

//         int max = array[0];

//         for (int i = 1; i < array.Length; i++)
//         {
//             if (array[i] > max)
//             {
//                 max = array[i];
//             }
//         }

//         return max;
//     }

//     static int EvaluateFormula(string? formula, int n)
//     {
//         if (formula == null)
//         {
//             Console.WriteLine("Invalid formula. Using default value of 0.");
//             return 0;
//         }
//         try
//         {
//             int result = (int)new System.Data.DataTable().Compute(formula.Replace("n", n.ToString()), "");
//             return result;
//         }
//         catch (Exception)
//         {
//             Console.WriteLine("Invalid formula. Using default value of 0.");
//             return 0;
//         }
//     }
// }


//----------SIMPLE FOR LOOP------------

// using System;

// class Program
// {
//     static void Main()
//     {
//         Console.WriteLine("Number   |  Square Root");
//         Console.WriteLine("------------------------");

//         for (int i = 1; i <= 10; i++)
//         {
//             double squareRoot = Math.Sqrt(i);
//             Console.WriteLine($"{i,-9} |  {squareRoot}");
//         }
//     }
// }
