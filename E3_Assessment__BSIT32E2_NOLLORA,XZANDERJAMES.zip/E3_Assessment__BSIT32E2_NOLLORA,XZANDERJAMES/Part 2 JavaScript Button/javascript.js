function checkNumber() {
    var userInput = prompt("Enter a number:");

    var number = parseInt(userInput);

    var result = (number % 2 === 0) ? "Even" : "Odd";
    document.getElementById("resultParagraph").textContent = "The number is " + result + ".";
}